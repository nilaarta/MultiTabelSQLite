package com.example.multitablesqlite.Features.CourseCRUD.CreateCourse;

public interface SubjectCreateListener {
    void onSubjectCreated(Subject subject);
}
