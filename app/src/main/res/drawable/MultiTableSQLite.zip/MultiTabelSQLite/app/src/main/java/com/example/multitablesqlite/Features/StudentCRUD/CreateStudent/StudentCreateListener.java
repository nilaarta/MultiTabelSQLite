package com.example.multitablesqlite.Features.StudentCRUD.CreateStudent;

public interface StudentCreateListener {
    void onStudentCreated(Student student);
}
